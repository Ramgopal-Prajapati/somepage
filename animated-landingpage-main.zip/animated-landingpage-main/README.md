# animated-landingpage
A landing page with beautiful animations created using pure HTML and CSS.
